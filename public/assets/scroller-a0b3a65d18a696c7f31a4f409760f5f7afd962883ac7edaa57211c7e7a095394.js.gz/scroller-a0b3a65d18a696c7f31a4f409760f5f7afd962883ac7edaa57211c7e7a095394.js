$( '.know-more' ).on( 'click', function( e ) {
  e.preventDefault();

  $( window ).scrollTo( '.tabs-services', 800 );
});
