document.addEventListener('DOMContentLoaded', function() {
  setTimeout(function() {
      $('body').addClass('loaded');
  }, 2000);
});
